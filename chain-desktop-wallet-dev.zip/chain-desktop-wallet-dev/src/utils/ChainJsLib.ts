import chainjs from '@crypto-org-chain/chain-jslib';

export const { HDKey, Units, Secp256k1KeyPair } = chainjs;
export const { Bytes, Big } = chainjs.utils;
